--BEGIN TXN

-- cleanup temporary structures
drop table temp_prop_root_ref; --(optional)
drop table temp_prop_root_obs; --(optional)
drop table temp_prop_val_ref; --(optional)
drop table temp_prop_val_obs; --(optional)
drop table temp_del_str1; --(optional)
drop table temp_del_str2; --(optional)
drop table temp_del_ser1; --(optional)
drop table temp_del_ser2; --(optional)
drop table temp_del_double1; --(optional)
drop table temp_del_double2; --(optional)

--END TXN